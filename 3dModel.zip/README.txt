                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3548757
OctoPrint Monitor by TucksProjects is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This is a Mac Classic version of **Qrome's** OctoPrint Monitor so I'm going to quote his summary 

This is a station box designed for the Wemos D1 Mini and the standard 0.96" 128x64 OLED display. Get creative with Arduino code or load some of the awesome Wemos applications out there.

The Wemos D1 mini will slide in and is held in place by the back plate. The display will need to be glued in with a dab of glue on each corner.

Code and Project:
You can monitor your 3D Printer's OctoPrint Server using a Wemos D1 Mini ESP8266 and a I2C SSD1306 OLED Display over a wifi connection. The 3D Printing files (STL) are freely available. The source code link down below. (Note: some have reported that it works out of the box with AstroPrint as well.)

Features:

Displays the print status from OctoPrint Server
* Estimated time remaining
* Time Printing
* Percentage complete
* Progress bar
* Bed and Tool Temperature
* Screen turns off when printer is turned off or disconnected
* Screen turns on when printer is Operational or connected
* Option to display a clock screen instead of sleep mode
* Option to show 24 hour clock mode
* Sample rate is every 60 seconds when not printing
* Sample rate is every 10 seconds when printing
* Fully configurable from the web interface (not required to update Settings.h)
* Supports OTA (loading firmware over WiFi connection on same LAN)
* Basic Athentication to protect your settings
* Supports SSD1306 and SSH1106 (since version 1.8)

NOTE: This case now has a big brother that supports the larger 1.3" I2C OLED display. You can find it here: https://www.thingiverse.com/thing:2934049

Hardware:

Wemos D1 Mini: https://amzn.to/2ImqD1n
White I2C OLED Display: https://amzn.to/2InSNF0
Blue I2C OLED Display: https://amzn.to/2HAmDd1
Blue / Yellow I2C OLED Display: https://amzn.to/2x11d43
Note: SPI Serial OLED is not supported
Please note that using the links provided here help to support these types of projects. Thank you for the support.

Download Source Code:
https://github.com/Qrome/printer-monitor

Detailed Build Video by Chris Riley: https://youtu.be/Rm-l1FSuJpI
Video: https://youtu.be/niRv9SCgAPk

Please share your makes!